import React, { Component } from 'react';

class UnitsList extends Component {
    render() {
        return (
            <div>
                <h1>Units List</h1>
            </div>
        );
    }
}

export default UnitsList;