import React, { Component } from 'react';

class UnitUpdate extends Component {
    render() {
        return (
            <div>
                <h1>Unit Update</h1>
            </div>
        );
    }
}

export default UnitUpdate;